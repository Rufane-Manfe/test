<script src="<?php echo ShareaholicUtilities::asset_url_admin( 'assets/pub/shareaholic-chat.js' ); ?>" async></script>
