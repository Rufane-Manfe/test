<div class="col-sm-4">
	<!--<div class="signuppromo">
	<p class="promoh1">
		<?php echo sprintf( __( 'Link to Shareaholic.com to unlock:', 'shareaholic' ) ); ?>
	</p>
	<ul>
		<li><?php echo sprintf( __( 'Analytics', 'shareaholic' ) ); ?></li>
		<li><?php echo sprintf( __( 'Floating Share buttons', 'shareaholic' ) ); ?></li>
		<li><?php echo sprintf( __( 'Social Share Count Recovery', 'shareaholic' ) ); ?></li>
		<li><?php echo sprintf( __( 'Follow buttons', 'shareaholic' ) ); ?></li>
		<li><?php echo sprintf( __( 'Share Buttons for Images', 'shareaholic' ) ); ?></li>
		<li><?php echo sprintf( __( 'Earnings Dashboard', 'shareaholic' ) ); ?></li>
		<li><?php echo sprintf( __( '...lots more!', 'shareaholic' ) ); ?></li>
	</ul>
	<a href="<?php echo esc_url( admin_url( 'admin.php?shareaholic_redirect_url=shareaholic.com/signup/' ) ); ?>" target="_blank" class="btn btn-info btn-lg" role="button" style="font-size: 16px;"><?php echo sprintf( __( 'Shareaholic Dashboard', 'shareaholic' ) ); ?></a>
	<p class="signuppromo_note">
		<?php echo sprintf( __( 'Already have a Shareaholic account? Click the button above to log in.', 'shareaholic' ) ); ?>
	</p>
	</div>
	-->

	<div class="sidebar_links">
	<div id="shrsb-updates">
		<div id="shrsb-updates-container"></div>
	</div>
	</div>

</div>
