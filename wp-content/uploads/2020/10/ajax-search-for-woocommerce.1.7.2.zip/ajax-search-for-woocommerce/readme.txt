=== Ajax Search for WooCommerce  ===
Contributors: damian-gora
Tags: woocommerce search, ajax search, search by sku, product search, woocommerce
Requires at least: 5.0
Tested up to: 5.5
Requires PHP: 5.5
Stable tag: 1.7.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The most popular WooCommerce product search plugin. Gives your users a well-designed advanced AJAX search bar with live search suggestions.

== Description ==

The most popular **WooCommerce product search plugin**. Gives your users a well-designed advanced AJAX search bar with live search suggestions.

By default, WooCommerce provides a very simple search solution, without live product search or even SKU search. Ajax Search for WooCommerce provides advanced search with live suggestions.

Who doesn’t love instant, as-you-type suggestions? In 2020, customers simply expect smart product search. Baymard Institute’s latest UX research reveals that search autocomplete, auto-suggest, or instant search feature **is now offered at 96% of major e-commerce sites**. It's a must-have feature for every online business that can’t afford to lose customers. Why? AJAX search helps users save time and makes shopping easier. As a result, it really boosts sales.

= Features =
&#9989; **Search by product title, long and short description**
&#9989; **Search by SKU**
&#9989; Show **product image** in live search results
&#9989; Show **product price** in live search results
&#9989; Show **product description** in live search results
&#9989; Show **SKU** in live search results
&#9989; **Mobile First** – special mobile search mode for better UX
&#9989; **Details panels** with extended information – **"add to cart" button** with a **quantity field** and **extended product** data displayed on hovering over the live suggestion
&#9989; **Easy implementation** in your theme - embed the plugin using a **shortcode**, as a **menu item** or as a **widget**
&#9989; **Terms search** – search for product categories and tags
&#9989; **Limit** displayed suggestions – the number is customizable
&#9989; **The minimum number of characters** required to display suggestions – the number is customizable
&#9989; **Better ordering** – a smart algorithm ensures that the displayed results are as accurate as possible
&#9989; **Support for the results page** - after type enter users got the same results as in ajax search bar
&#9989; **Grouping instant search results by type** – displaying e.g. first matching categories, then matching products
&#9989; **Google Analytics** support
&#9989; **WPML** compatible
&#9989; **Polylang** compatible
&#9989; **Personalization** of search bar and autocomplete suggestions - labels, colors, preloader, image and more

= Try the PRO version =
Ajax search comes also in the Pro version, with a modern, inverted index based search engine. Ajax Search Pro works **even 10x faster** than its Free version or other popular search solutions for WooCommerce.

[Upgrade to PRO and boost your sales!](https://ajaxsearch.pro/pricing/?utm_source=readme&utm_medium=referral&utm_content=pricing&utm_campaign=asfw)

= PRO features =

&#9989; **Ultra-Fast Search Engine** based on the inverted index – works very fast even with 100,000+ products
&#9989; **Fuzzy search** – works even with minor typos
&#9989; **Search in custom fields**
&#9989; **Search in attributes**
&#9989; **Search in categories**
&#9989; **Search in tags**
&#9989; **Search in brands** (WooCommerce Brands or YITH WooCommerce Brands)
&#9989; **Search by variation product SKU** – also shows variable products in live search after typing in the exact matching SKU
&#9989; **Search for posts** – shows also matching posts in live search
&#9989; **Search for pages** – shows also matching posts in live search
&#9989; **Synonyms**
&#9989; Professional and fast **help with embedding** or replacing the search bar in your theme
&#9989; and more...
&#9989; SEE ALL PRO [FEATURES](https://ajaxsearch.pro?utm_source=readme&utm_medium=referral&utm_content=features&utm_campaign=asfw#features-comparison)!

= Showcase =
See how it works for others: [Showcase](https://ajaxsearch.pro/showcase/?utm_source=readme&utm_medium=referral&utm_campaign=asfw&utm_content=showcase&utm_gen=utmdc).

= Feedback =
Any suggestions or comments are welcome. Feel free to contact me via the [contact form](https://ajaxsearch.pro/contact/?utm_source=readme&utm_medium=referral&utm_campaign=asfw&utm_content=contact&utm_gen=utmdc).

== Installation ==

1. Install the plugin from within the Dashboard or upload the directory `ajax-search-for-woocommerce` and all its contents to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to `WooCommerce -> AJAX Search bar` and set your preferences.
4. Use a shortcode `[wcas-search-form]` or go to the `Appearance -> Menu` and add menu item `AJAX Search bar` or go to the `Appearance -> Widgets` and choose `AJAX Search bar`

== Frequently Asked Questions ==

= How do I embed the search bar in my theme? =
There are five easy ways to display the AJAX search box in your theme:

– **As a menu item** - in your WordPress admin panel, go to `Appearance -> Menu` and add `AJAX Search bar` as a menu item
– **Using a shortcode**

`[wcas-search-form]`

– **As a widget** - in your WordPress admin panel, go to `Appearance -> Widgets` and choose `AJAX Search bar`

– **Using PHP**

`<?php echo do_shortcode('[wcas-search-form]'); ?>`

– **We will do it for you!** - we offer free of charge search bar implementation for Pro users. Become one now!

Or insert this function inside php file ( often it used to insert form inside page templates files ):

= How do I replace the existing search bar in my theme with AJAX Search? =
We have prepared a one-click replacement of search bar for the following themes:

*  Storefront
*  Flatsome
*  OceanWP
*  Astra
*  Avada
*  and 13 more... See complete list of integrated themes on [our docs](https://ajaxsearch.pro/docs/integrations/?utm_source=readme&utm_medium=referral&utm_campaign=asfw&utm_content=theme-integrations).


If you want to replace your search bar in some other theme, please [contact our support team](https://ajaxsearch.pro/contact/?utm_source=readme&utm_medium=referral&utm_campaign=asfw&utm_content=contact&utm_gen=utmdc)
Also, we have developed snippets to replace the search bar in Porto, Autusin, Avada, Hestia, Electro and more themes. We will share the code soon.
We offer replacing the search bar in your theme for free after you upgrade to the Pro version.

= Can I add the search bar as a WordPress menu item? =
**Yes, you can!** Go to `Appearance -> Menu`. You will see a new menu item called "AJAX Search bar". Select it and click "Add to menu". Done!

= I have a question, where do I ask? =
You can submit a ticket on the plugin [website](https://ajaxsearch.pro/contact/?utm_source=readme&utm_medium=referral&utm_campaign=asfw&utm_content=contact&utm_gen=utmdc) and the support team will get in touch with you shortly. We also answer questions on the [WordPress Support Forum](https://wordpress.org/support/plugin/ajax-search-for-woocommerce/).

= Do you offer customization support? =
Depending on the them you use, sometimes the search bar requires minor improvements in appearance. We guarantee fast CSS corrections for all Pro plugin users, but we also help Free plugin users.

= Where can I find plugin settings? =
In your WordPress admin panel, go to `WooCommerce -> AJAX Search bar`. The AJAX search settings page is a submenu of the WooCommerce menu.

= Who is the Pro plugin version for? =
The Pro plugin version is for all online sellers looking to **increase sales** by providing an ultra-fast and smart search engine to their clients.

The main difference between the Pro and Free versions is search speed and search scope. The Pro version has a new fast and smart search engine. For some online stores that offer a lot of products for sale, search speed can be increased **up to 10x**, providing a whole new experience to end users.

All in all, the Pro version is dedicated to all WooCommerce shops where autocomplete suggestions work too slow.

You can read more and compare Pro and Free features here: [feature comparison](https://ajaxsearch.pro/#features-comparison).

== Screenshots ==

1. Search suggestions with the details panel
2. Search suggestions
3. Search bar options
4. Autocomplete options
5. Search config

== Changelog ==

= 1.7.2, July 12, 2020 =
* ADD: Integration with FacetWP plugin
* ADD: Support for Shopkeeper theme
* ADD: Support for The7 theme
* ADD: Support for Avada theme
* ADD: Support for Shop Isle theme
* ADD: Support for Shopical theme
* ADD: Support for Ekommart theme
* ADD: Support for Savoy theme
* ADD: Support for Sober theme
* ADD: Support for Bridge theme
* ADD: Possibility to change search icon color
* ADD: New filter hook for a search form value
* ADD: Support for Site Search module in Google Analytics
* FIX: Add CSS border-box for each elements in search bar, suggestions and details panel
* FIX: Sending events to Google Tag Manager
* FIX: Remove &lt;b&gt; from product title
* FIX: Search in categories and tags for Russian terms
* FIX: Duplicated category in breadcrumb
* FIX: No results when searching for phrase included apostrophe or double quote
* FIX: Details panel - Remove HTML from titles attribute
* FIX: Fixed for integration with Woo Product Filter plugin by WooBeWoo
* FIX: Fixed for integration with XforWooCommerce plugin
* FIX: Error: Undefined index: is_taxonomy in some cases


= 1.7.1, May 17, 2020 =
* FIX: Selecting suggestions issue

= 1.7.0, May 17, 2020 =
* ADD: Icon search instead of search bar (beta)
* ADD: Improvements on search results pages
* ADD: Integration with native WooCommerce filters
* ADD: Integration with Advanced AJAX Product Filters plugin by BeRocket
* ADD: Integration with WOOF – Products Filter for WooCommerce plugin by realmag777
* ADD: Integration with Product Filters for WooCommerce plugin by Automattic developed by Nexter
* ADD: Integration with Woo Product Filter plugin by WooBeWoo
* ADD: Integration with WooCommerce Product Table plugin by Barn2 media
* ADD: Support for TheGem theme
* ADD: Support for Impreza theme
* ADD: Support for Medicor theme
* ADD: Support for WoodMart theme
* ADD: Support for Polylang
* ADD: New filter and action hooks
* ADD: Dynamically loaded prices for WPML Multi-currency feature
* FIX: Mobile search - don't hide suggestions on blur
* FIX: Bug related to highlight keywords. For some cases it displayed &lt;strong&gt; tag.
* FIX: Delay on mouse hover effect
* FIX: Minor CSS improvements
* FIX: Broken mobile view on cart page in some cases


= 1.6.3, March 11, 2020 =
* ADD: Details panel - display stock quantity
* FIX: Better support for the Elementor including popups and sticky menu
* FIX: Better support for page builders. Late initialization.
* FIX: Disabling automatic regenerate thumbnails. Conditionally images regeneration.
* FIX: HTTP 500 on getResultDetails for some cases
* FIX: Too long description in live suggestions
* FIX: Add non-breaking space for prices
* FIX: JS errors Failed to execute 'getComputedStyle' on 'Window' (for some cases)
* CHANGE: Rename jQuery object from Autocomplete to DgwtWcasAutocompleteSearch because of namespaces conflicts


= 1.6.2, February 18, 2020 =
* ADD: Details Panel - new layout for product overview and other UX improvements
* ADD: Automatically regenerates images after first plugin activation


* FIX: Highlighted no results suggestion
* FIX: Better security

= 1.6.1, January 26, 2020 =

* ADD: Details Panel - grouped load, faster load
* ADD: New way to embed search box - embedding by menu
* ADD: Details panel - show "more products..." link for taxonomy type suggestion
* ADD: Add &lt;form&gt; to quantity elements in a details panel
* ADD: New filters and actions hook

* FIX: Issue related to colors in plugin settings
* FIX: Suggestions groups - improved limits
* FIX: Pricing for taxonomy term in a details panel
* FIX: Show a details panel on keys UP and DOWN
* FIX: Mobile search overlay - block scroll of &lt;html&gt; tag (issue on iPhones)
* FIX: Better data-wcas-context ID, bypasses opcache
* FIX: W3C - Accessibility errors
* FIX: Storefront mobile search - more time for input autofocus
* FIX: Disable quantity for Astra Pro theme - there were broken buttons
* FIX: Minor CSS improvements

* CHANGE:  Decrease debounce time for better speed effect
* CHANGE: Updated Freemius SDK v2.3.2

= 1.6.0, December 08, 2019 =

* ADD: Suggestions groups
* ADD: Hide advanced settings
* ADD: Better grouping of settings
* ADD: Support for Google Analytics events
* ADD: Search bar preview in settings
* ADD: New action and filters hooks
* FIX: Flatsome theme support for [search] shortcode
* FIX: Images in details panel
* CHANGE: Updated Freemius SDK
* REMOVE: Remove ontouch event from mobile detect



= 1.5.0, September 16, 2019 =

* ADD: Integration with the Flatsome theme. It is possible to replace the Flatsome search form via one checbox in the plugin settings page.
* FIX: Overload servers. Optimalization for chain AJAX requests. Creates a debounced function that delays invoking func until after wait milliseconds have elapsed since the last time the debounced function was invoked
* FIX: Better support for HTML entities in products title and description
* FIX: Issues with mobile search version on Storefront theme for iPhones
* CHANGE: Update/sync fork of devbridge/jQuery-Autocomplete to the latest version
* CHANGE: Settings design

= 1.4.1, August 05, 2019 =

* ADD: French translations
* FIX: Better support for fixed menu
* FIX: Add box-sizing to the search input to better implementation for some themes
* FIX: Duplicated class Mobile_Detect in some cases
* FIX: Submit button position in some cases
* FIX: Zoom in iPhones on focused input
* FIX: Size of images for categories and tags in the Details panel
* CHANGE: Updated Freemius SDK

= 1.4.0, May 04, 2019 =

* ADD: New modern mobile search UX (beta, disabled by default, enabled only for Storefront theme)
* ADD: Italian translations
* ADD: Spain translations
* FIX: Error with WP Search WooCommerce Integration
* FIX: Conflict with the Divi theme for some cases
* CHANGE: Implementing flexbox grid (CSS)

= 1.3.3, March 02, 2019 =

* FIX: Deactivate browser native "X" icon for search input
* FIX: Products images for tags and categories in Details panel
* FIX: Security fix
* ADD: New logos
* CHANGE: Updated Freemius SDK



= 1.3.2, February 16, 2019 =

* ADD: The text "No results" and "See all results..." can be customized in the plugin settings
* ADD: New filters and hooks
* FIX: Hide the "Account" link in the free plugin versions
* FIX: The error with the appearance of the tags suggestion
* FIX: Problem with artificially duplicated search forms occurred in the Mega Menu plugin and some themes.
* CHANGE: Enforcing use "box-sizing: border-box" within the search form
* CHANGE: Updated Freemius SDK

= 1.3.1, January 06, 2019 =
* FIX: PHP error with widget

= 1.3.0, January 06, 2019 =

* ADD: If there are more results than limit, the "See all results..." link will appear
* ADD: Information about the PRO features
* ADD: Breadcrumbs for nested product categories
* FIX: Better synchronization between the ajax search results and the search page
* FIX: Improvements in the scoring system
* FIX: Image placeholder for products without image
* FIX: Add SKU label translatable in the suggestions
* CHANGE: Updated Freemius SDK

= 1.2.1, October 26, 2018 =
* ADD: Storefront support as a option. Allows to replace the native Storefront search form
* FIX: Improving the relevance of search results by adding score system
* FIX: Problem with too big images is some cases
* FIX: Support for HTML entities in the search results
* FIX: Bugs with the blur event on mobile devices

= 1.2.0, August 24, 2018 =
* ADD: Backward compatibility system
* ADD: Support of image size improvements in Woocommerce 3.3
* ADD: Dynamic width of the search form
* ADD: Option to set max width of the search form
* ADD: DISABLE_NAG_NOTICES support for admin notices
* ADD: More hooks for developers
* ADD: Minified version of CSS and JS
* ADD: Label for taxonomy suggestions
* ADD: Quantity input for a add to cart button in the Details panel
* FIX: Problem with covering suggestions by other HTML elements of themes.
* FIX: Details panel in RTL
* FIX: Improvements for the IE browser
* CHANGE: Code refactor for better future development. Composer and PSR-4 support (in part).
* CHANGE: Better settings organization
* CHANGE: Updated Freemius SDK

= 1.1.7, April 22, 2018 =
* FIX: Removed duplicate IDs
* CHANGE: PHP requires tag set to PHP 5.5
* CHANGE: Woocommerce requires tags
* CHANGE: Updated Freemius SDK
* REMOVE: Removed uninstall.php

= 1.1.6, October 01, 2017 =
* FIX: Disappearing some categories and tags in suggestions
* FIX: Hidden products were shown in search

= 1.1.5, September 05, 2017 =
* ADD: Requires PHP tag in readme.txt
* FIX: PHP Fatal error for PHP &lt; 5.3

= 1.1.4, September 03, 2017 =
* ADD: Admin notice if there is no WooCommerce installed
* ADD: Admin notice for better feedback from users
* FIX: Deleting the 'dgwt-wcas-open' class after hiding the suggestion
* FIX: Allows to display HTML entities in suggestions title and description
* FIX: Better synchronizing suggestions and resutls on a search page
* CHANGE: Move menu item to WooCommerce submenu

= 1.1.3, July 12, 2017 =
* ADD: New WordPress filters
* FIX: Repetitive search results
* FIX: Extra details when there are no results

= 1.1.2, June 7, 2017 =
* FIX: Replace deprecated methods and functions in WC 3.0.x

= 1.1.1, June 6, 2017 =
* ADD: Added Portable Object Template file
* ADD: Added partial polish translation
* FIX: WooCommerce 3.0.x compatible
* FIX: Menu items repeated in a search page
* FIX: Other minor bugs

= 1.1.0, October 5, 2016 =
* NEW: Add WPML compatibility
* FIX: Repeating search results for products in a admin dashboard
* FIX: Overwrite default input element rounding for Safari browser

= 1.0.3.1, July 24, 2016 =
* FIX: Disappearing widgets
* FIX: Trivial things in CSS

= 1.0.3, July 22, 2016 =
* FIX: Synchronization WP Query on a search page and ajax search query
* CHANGE: Disable auto select the first suggestion
* CHANGE: Change textdomain to ajax-search-for-woocommerce

= 1.0.2, June 30, 2016 =
* FIX: PHP syntax error with PHP version &lt; 5.3

= 1.0.1, June 30, 2016 =
* FIX: Excess AJAX requests in a detail mode
* FIX: Optimization JS mouseover event in a detail mode
* FIX: Trivial things in CSS

= 1.0.0, June 24, 2016 =
* ADD: [Option] Exclude out of stock products from suggestions
* ADD: [Option] Overwrite a suggestion container width
* ADD: [Option] Show/hide SKU in suggestions
* ADD: Add no results note
* FIX: Search in products SKU
* FIX: Trivial things in CSS and JS files

= 0.9.1, June 5, 2016 =
* ADD: Javascript and CSS dynamic compression
* FIX: Incorrect dimensions of the custom preloader

= 0.9.0, May 17, 2016 =
* ADD: First public release
